<!DOCTYPE html>
<html lang="en">
<head>
<title>STAGE-1 ASSIGNMENT</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container-fluid">
        ​<div class="row">
            <div class="col-md-12">
                <a href="/bucket"><button type="button" class="btn btn-primary">Bucket Form</button></a>
                <a href="/ball"><button type="button" class="btn btn-secondary">Ball Form</button></a>
                <a href="/bucket-suggestion"><button type="button" class="btn btn-success">Bucket Suggestion</button></a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-3" style="padding: 15px;">
                <h4>Bucket</h4><hr>
                <form action="<?php echo e(url('/bucket/store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="">Name:</label>
                    <input type="text" name="name" id="" required><br><br>
    
                    <label for="">Value:</label>
                    <input type="number" name="value" id="" required><br><br>
    
                    <button type="submit" class="btn btn-success">Save</button>
                    <span style="color: red;" min-height="10px" max-height="10px"> &nbsp; <?php if(Session::has('Failed')): ?><?php echo e(Session::get('Failed')); ?><?php endif; ?></span>
                    <span style="color: green;" min-height="10px" max-height="10px"> &nbsp; <?php if(Session::has('Success')): ?><?php echo e(Session::get('Success')); ?><?php endif; ?></span>
                </form>
                
                <div class="table-responsive">
                    <table class="table table-striped" id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>Sr No.</th>
                                <th>Name</th>
                                <th>Value</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $x=1; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($x++); ?></td>
                                <td><?php echo e($datas->name); ?> </td>
                                <td><?php echo e($datas->value); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-md-8">
            
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\Dhanendra Kumar\Downloads\project\resources\views/bucket.blade.php ENDPATH**/ ?>