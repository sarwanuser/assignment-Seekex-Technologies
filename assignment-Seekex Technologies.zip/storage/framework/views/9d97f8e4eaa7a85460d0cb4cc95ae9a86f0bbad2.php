<!DOCTYPE html>
<html lang="en">
<head>
<title>STAGE-1 ASSIGNMENT</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container-fluid">
        ​<div class="row">
            <div class="col-md-12">
                <a href="/bucket"><button type="button" class="btn btn-primary">Bucket Form</button></a>
                <a href="/ball"><button type="button" class="btn btn-secondary">Ball Form</button></a>
                <a href="/bucket-suggestion"><button type="button" class="btn btn-success">Bucket Suggestion</button></a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-3" style="padding: 15px;">
                <h4>Bucket Suggestion</h4><hr>
                <form action="<?php echo e(url('/bucket-suggestion/calculate')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label style="width: 70px;">PINK:</label>
                    <input type="text" name="pink" value="<?php echo e(@$post['pink']); ?>" required><br><br>

                    <label style="width: 70px;">RED:</label>
                    <input type="text" name="red" value="<?php echo e(@$post['red']); ?>" required><br><br>

                    <label style="width: 70px;">BLUE:</label>
                    <input type="text" name="blue" value="<?php echo e(@$post['blue']); ?>" required><br><br>

                    <label style="width: 70px;">ORANGE:</label>
                    <input type="text" name="orange" value="<?php echo e(@$post['orange']); ?>" required><br><br>

                    <label style="width: 70px;">GREEN:</label>
                    <input type="text" name="green" value="<?php echo e(@$post['green']); ?>" required><br><br>


                    <button type="submit" class="btn btn-success">SUGGEST ME BUCKETS</button>
                    <span style="color: red;" min-height="10px" max-height="10px"> &nbsp; <?php if(Session::has('Failed')): ?><?php echo e(Session::get('Failed')); ?><?php endif; ?></span>
                    <span style="color: green;" min-height="10px" max-height="10px"> &nbsp; <?php if(Session::has('Success')): ?><?php echo e(Session::get('Success')); ?><?php endif; ?></span>
                </form>
            </div>
            <div class="col-md-5">
                <h4>Result</h4>
                <p>Following are the suggested buckets:</p>
                <div class="table-responsive">
                    <table class="table table-hover" id="datatablesSimple">
                        <thead style="font-size: 12px;">
                            <tr>
                                <th>BUCKET</th>
                                <th>EMPTY VOLUME</th>
                                <th>BALL</th>
                                <th>NO. OF BALLS CAN BE PUT</th>
                                <th>Message</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php if(@$result): ?>
                            <?php $__currentLoopData = @$result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($rdata['bucket']); ?></td>
                                <td><?php echo e($rdata['empty']); ?></td>
                                <td><?php echo e($rdata['ball']); ?></td>
                                <td><?php echo e($rdata['no_ball']); ?></td>
                                <td><?php echo e($rdata['msg']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-md-2">
                <h4>Bucket</h4>
                <div class="table-responsive">
                    <table class="table table-hover" id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Value</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $x=1; ?>
                            <?php $__currentLoopData = $buckets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bucket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($bucket->name); ?> </td>
                                <td><?php echo e($bucket->value); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="col-md-2">
                <h4>Ball</h4>
                <div class="table-responsive">
                    <table class="table table-hover" id="datatablesSimple">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Value</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $x=1; ?>
                            <?php $__currentLoopData = $balls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ball): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ball->name); ?> </td>
                                <td><?php echo e($ball->value); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\Dhanendra Kumar\Downloads\project\resources\views/bucketsuggestion.blade.php ENDPATH**/ ?>