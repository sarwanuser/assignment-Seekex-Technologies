<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Purchase Record</title>
    <style>
        .tab {
        overflow: hidden;
        border: 1px solid #ccc;
        background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */
        .tab button {
        background-color: inherit;
        float: left;
        border: none;
        outline: none;
        cursor: pointer;
        padding: 14px 16px;
        transition: 0.3s;
        font-size: 17px;
        }

        /* Change background color of buttons on hover */
        .tab button:hover {
        background-color: #ddd;
        }

        /* Create an active/current tablink class */
        .tab button.active {
        background-color: #ccc;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="tab">
                <a href="<?php echo e(url('/sales')); ?>"><button class="tablinks">Sale</button></a>
                <a href="<?php echo e(url('/purchases')); ?>"><button class="tablinks" style="background-color:lightblue;color:green">Purchase</button></a>
            </div>

            <div class="" style="padding: 15px;">
                <form action="<?php echo e(url('/purchases/store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="">Name:</label>
                    <input type="text" name="name" id="" required><br><br>
    
                    <label for="">Value:</label>
                    <input type="number" name="value" id="" required><br><br>
    
                    <button type="submit" class="btn btn-success">Save</button>
                    <span style="color: red;" min-height="10px" max-height="10px"> &nbsp; <?php if(Session::has('Failed')): ?><?php echo e(Session::get('Failed')); ?><?php endif; ?></span>
                    <span style="color: green;" min-height="10px" max-height="10px"> &nbsp; <?php if(Session::has('Success')): ?><?php echo e(Session::get('Success')); ?><?php endif; ?></span>
                </form>
            </div>

            <div class="col-md-2">&nbsp;</div>
            <div class="col-md-8">
                <div class="table-responsive">
                <table class="table table-hover" id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>Sr No.</th>
                            <th>Name</th>
                            <th>Value</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $x=1; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($x++); ?></td>
                            <td><?php echo e($datas->name); ?> </td>
                            <td><?php echo e($datas->value); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
            </div>
            <div class="col-md-2">&nbsp;</div>
        </div>
    </div>
</body>
</html><?php /**PATH E:\Lumen\Task\project\resources\views/purchase.blade.php ENDPATH**/ ?>