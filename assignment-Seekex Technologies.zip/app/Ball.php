<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ball extends Model
{
    protected $table = 'balls';

    protected $primaryKey = 'id';
}
