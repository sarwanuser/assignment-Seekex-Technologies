<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bucket extends Model
{
    protected $table = 'buckets';

    protected $primaryKey = 'id';
}
